
package com.developer.Ship_Manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShipManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShipManagerApplication.class, args);
	}

}
